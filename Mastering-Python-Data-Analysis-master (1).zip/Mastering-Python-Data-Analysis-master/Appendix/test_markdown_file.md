# A Markdown text file for you to edit
---

Some of the markdown syntax is rendered, such as headings.
Others not, like
* bullet lists.
* They are not rendered..

## Images
Or images:
![test image](./test.png)

## Syntax highlighting
However, much of the syntax is highlighted though.

